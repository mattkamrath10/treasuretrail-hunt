TreasureTrail - Code changes between the rejected build and the current build
============================================================================

These are the source-code and config files that changed in order to clear the
Apple Guideline 3.1.2(c) rejection and lower prices.

Summary of changes:
  - Pro Seller price lowered $9.99 -> $5.99 / month
  - Event Boost price lowered to $1.99
  - In-app auto-renewable subscription disclosure (title, length, price,
    auto-renew terms) shown on the Membership screen before purchase
  - Functional Terms of Use (EULA) + Privacy Policy links on that screen
  - iPad screenshot download helper page

Files included (current versions):
  src/pages/Pro.tsx           - subscription disclosure + price + legal links
  src/lib/entitlements.ts     - product pricing/labels
  src/lib/iap.ts              - in-app purchase price fallbacks
  src/pages/EventDetail.tsx   - boost price label
  src/pages/LiveHub.tsx       - boost price label
  src/pages/WantedDetail.tsx  - boost price label
  package.json                - dev tooling for screenshots
  ipadshots.mjs               - screenshot generator (dev helper)
  public/ipad-screenshots.html- screenshot download page

CHANGES.txt contains the exact line-by-line diff of these code files.
