import { supabase } from './supabase';
import { assertClean, GUIDELINE_MESSAGE } from './contentFilter';

export type EventCategory =
  | 'estate_sale'
  | 'yard_sale'
  | 'flea_market'
  | 'auction'
  | 'pop_up'
  | 'collectibles_show'
  | 'other';

export type EventStatus = 'draft' | 'published' | 'cancelled';

export type EventKind = 'local' | 'online';

export type EventPlatform =
  | 'whatnot'
  | 'poshmark_live'
  | 'posh_party'
  | 'ebay_live'
  | 'other';

export type ShowCategory =
  | 'sneakers'
  | 'sportscards'
  | 'tradingcards'
  | 'coins'
  | 'jewelry'
  | 'vintage'
  | 'collectibles'
  | 'fashion'
  | 'toys'
  | 'art'
  | 'other';

/**
 * Per-platform metadata for badges, branding, and URL validation.
 *
 * `urlPattern` is mirrored from the DB CHECK constraint in
 * 20260527000002_phase2_online_events.sql — keep both in sync if either
 * changes, or the form will silently let users save URLs the DB then
 * rejects (or vice versa).
 */
export const PLATFORM_META: Record<
  EventPlatform,
  { label: string; color: string; urlPattern: RegExp; placeholderUrl: string }
> = {
  whatnot:       { label: 'Whatnot',       color: '#FFCC00', urlPattern: /^https:\/\/(www\.)?whatnot\.com\//i,                placeholderUrl: 'https://www.whatnot.com/live/...' },
  poshmark_live: { label: 'Poshmark Live', color: '#7C1F4E', urlPattern: /^https:\/\/(www\.)?(poshmark\.com|posh\.mk)\//i,    placeholderUrl: 'https://poshmark.com/show/...' },
  posh_party:    { label: 'Posh Party',    color: '#B83280', urlPattern: /^https:\/\/(www\.)?(poshmark\.com|posh\.mk)\//i,    placeholderUrl: 'https://poshmark.com/party/...' },
  ebay_live:     { label: 'eBay Live',     color: '#0064D2', urlPattern: /^https:\/\/(www\.)?ebay\.com\//i,                   placeholderUrl: 'https://www.ebay.com/live/...' },
  other:         { label: 'Other',         color: '#525252', urlPattern: /^https:\/\//i,                                       placeholderUrl: 'https://...' },
};

export const SHOW_CATEGORY_LABELS: Record<ShowCategory, string> = {
  sneakers:     'Sneakers',
  sportscards:  'Sports cards',
  tradingcards: 'Trading cards (TCG)',
  coins:        'Coins & bullion',
  jewelry:      'Jewelry',
  vintage:      'Vintage',
  collectibles: 'Collectibles',
  fashion:      'Fashion',
  toys:         'Toys',
  art:          'Art',
  other:        'Other',
};

export interface EventRow {
  id: string;
  holder_id: string;
  title: string;
  description: string;
  category: EventCategory;
  starts_at: string;
  ends_at: string | null;
  address: string | null;
  city: string | null;
  region: string | null;
  lat: number | null;
  lng: number | null;
  cover_image_url: string | null;
  cover_thumb_url: string | null;
  status: EventStatus;
  // Phase 2 — online live event fields.
  event_kind: EventKind;
  platform: EventPlatform | null;
  livestream_url: string | null;
  seller_handle: string | null;
  show_category: ShowCategory | null;
  // Optional external event page (Facebook event, estate-sale site, HiBid
  // auction, Whatnot stream, etc). Optional so rows fetched before the
  // `20260529000001_event_url.sql` migration lands still typecheck.
  event_url?: string | null;
  // Phase 1 monetization — boost + moderation. Optional so older code
  // paths that don't SELECT them still typecheck. See
  // `supabase/migrations/20260528000002_monetization_phase1.sql`.
  boosted_at?: string | null;
  boost_expires_at?: string | null;
  boost_type?: 'paid' | 'pro' | null;
  priority_score?: number | null;
  is_hidden?: boolean | null;
  report_count?: number | null;
  created_at: string;
  updated_at: string;
}

export interface EventFeaturedItem {
  id: string;
  event_id: string;
  title: string;
  price: number | null;
  image_url: string | null;
  thumb_url: string | null;
  position: number;
  created_at: string;
}

export interface EventUpsert {
  id?: string;
  title: string;
  description?: string;
  category: EventCategory;
  starts_at: string;
  ends_at?: string | null;
  address?: string | null;
  city?: string | null;
  region?: string | null;
  lat?: number | null;
  lng?: number | null;
  cover_image_url?: string | null;
  cover_thumb_url?: string | null;
  status: EventStatus;
  // Phase 2.
  event_kind?: EventKind;
  platform?: EventPlatform | null;
  livestream_url?: string | null;
  seller_handle?: string | null;
  show_category?: ShowCategory | null;
  // Optional external event page link (any kind of event).
  event_url?: string | null;
}

/* ---------------- Time-based helpers (Live now / Starting soon) ---------- */

const SOON_WINDOW_MS    = 60 * 60 * 1000;       // 60 min before start
const ASSUMED_SHOW_LEN  = 2  * 60 * 60 * 1000;  // online events without
                                                // an ends_at → assume 2h
                                                // window so "Live Now"
                                                // doesn't stick forever.

export function isStartingSoon(e: EventRow, now: number = Date.now()): boolean {
  const start = new Date(e.starts_at).getTime();
  return start > now && start - now <= SOON_WINDOW_MS;
}

export function isLiveNow(e: EventRow, now: number = Date.now()): boolean {
  const start = new Date(e.starts_at).getTime();
  if (start > now) return false;
  const end = e.ends_at
    ? new Date(e.ends_at).getTime()
    : (e.event_kind === 'online' ? start + ASSUMED_SHOW_LEN : start + ASSUMED_SHOW_LEN);
  return now < end;
}

/**
 * An online (Whatnot etc) event whose computed show window has
 * already closed. We can't poll the platform to confirm the stream
 * actually ended, so we treat the assumed-2h window after `starts_at`
 * (or the explicit `ends_at`) as the source of truth. Used to:
 *   - drop the "LIVE" badge,
 *   - re-label CTAs to "Open on Whatnot" / "Recently Live",
 *   - swap the dead livestream URL for the seller's storefront so
 *     users never land on Whatnot's "show ended" page.
 */
export function isExpiredLive(e: EventRow, now: number = Date.now()): boolean {
  if (e.event_kind !== 'online') return false;
  const start = new Date(e.starts_at).getTime();
  if (start > now) return false;
  const end = e.ends_at
    ? new Date(e.ends_at).getTime()
    : start + ASSUMED_SHOW_LEN;
  return now >= end;
}

/**
 * Best-effort storefront URL for a given event's seller. For Whatnot
 * we can reconstruct `https://www.whatnot.com/user/<handle>` from the
 * `seller_handle` field. For everything else (and as a final fallback)
 * we return the platform's browse/home page instead of a dead show
 * URL.
 */
export function platformStorefrontUrl(e: EventRow): string {
  const handle = (e.seller_handle ?? '').trim().replace(/^@/, '');
  switch (e.platform) {
    case 'whatnot':
      return handle ? `https://www.whatnot.com/user/${encodeURIComponent(handle)}` : 'https://www.whatnot.com/';
    case 'poshmark_live':
    case 'posh_party':
      return handle ? `https://poshmark.com/closet/${encodeURIComponent(handle)}` : 'https://poshmark.com/';
    case 'ebay_live':
      return handle ? `https://www.ebay.com/usr/${encodeURIComponent(handle)}` : 'https://www.ebay.com/';
    default:
      return 'https://www.whatnot.com/';
  }
}

/**
 * Resolve the URL the "Open" CTA should actually navigate to. If the
 * show is still inside its live window we send users to the real
 * livestream; once the window has closed we fall back to the seller's
 * storefront so they land on something real (and can follow / catch
 * the next show) instead of a dead page.
 */
export function resolveExternalEventUrl(e: EventRow, now: number = Date.now()): string | null {
  if (!e.livestream_url) return null;
  if (isExpiredLive(e, now)) return platformStorefrontUrl(e);
  return e.livestream_url;
}

/* ---------------- Queries ------------------------------------------------ */

/** Public feed of published events, soonest first.
 *
 * Hidden-row filtering is best-effort: until the Phase-1 monetization
 * migration (`20260528000002_monetization_phase1.sql`) lands, the
 * `is_hidden` column doesn't exist and Postgres returns 42703. We
 * detect that one error code and transparently retry without the
 * filter so the feed never goes blank during migration rollout. */
export async function fetchPublishedEvents(opts?: { city?: string | null; limit?: number }) {
  const build = (withHidden: boolean) => {
    let q = supabase
      .from('events')
      .select('*')
      .eq('status', 'published')
      .order('starts_at', { ascending: true })
      .limit(opts?.limit ?? 50);
    if (withHidden) q = q.eq('is_hidden', false);
    if (opts?.city) q = q.eq('city', opts.city);
    return q;
  };
  let { data, error } = await build(true);
  if (error?.code === '42703' && /is_hidden/i.test(error.message ?? '')) {
    console.warn('[FETCH_PUBLISHED_EVENTS] is_hidden column missing — retrying without moderation filter. Apply migration 20260528000002_monetization_phase1.sql to enable.');
    ({ data, error } = await build(false));
  }
  if (error) throw new Error(error.message);
  return (data ?? []) as EventRow[];
}

/**
 * Count a holder's *active local* events — used to enforce the free-tier
 * cap (1 active local event for free, unlimited for Pro). "Active" means
 * not cancelled; online live shows do not count against the local cap.
 * `excludeId` lets the edit form ignore the row being saved.
 *
 * The DB trigger in `20260529000003_free_tier_event_cap.sql` is the real
 * backstop; this client count drives the friendly pre-save UX so the user
 * sees an upgrade prompt instead of a raw Postgres error.
 */
export async function countActiveLocalEvents(holderId: string, excludeId?: string): Promise<number> {
  let q = supabase
    .from('events')
    .select('id', { count: 'exact', head: true })
    .eq('holder_id', holderId)
    .eq('event_kind', 'local')
    .neq('status', 'cancelled');
  if (excludeId) q = q.neq('id', excludeId);
  const { count, error } = await q;
  if (error) throw new Error(error.message);
  return count ?? 0;
}

/**
 * Resolve which of the given holder ids are Pro members. Used by Discover
 * to give Pro sellers priority placement. Best-effort: any error returns
 * an empty set so the feed still renders (Pro just loses its boost that
 * load) rather than blanking out.
 */
export async function fetchProHolderIds(holderIds: string[]): Promise<Set<string>> {
  const ids = [...new Set(holderIds)].filter(Boolean);
  if (ids.length === 0) return new Set();
  const { data, error } = await supabase
    .from('profiles')
    .select('id, membership_tier, pro_member')
    .in('id', ids);
  if (error) {
    console.warn('[FETCH_PRO_HOLDERS] failed — Pro priority placement skipped this load:', error.message);
    return new Set();
  }
  const set = new Set<string>();
  for (const p of data ?? []) {
    const row = p as { id: string; membership_tier?: string | null; pro_member?: boolean | null };
    if (row.membership_tier === 'pro' || row.pro_member) set.add(row.id);
  }
  return set;
}

/** All events owned by a holder (any status). */
export async function fetchMyEvents(holderId: string) {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('holder_id', holderId)
    .order('starts_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as EventRow[];
}

export async function fetchEvent(id: string) {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as EventRow | null;
}

/**
 * Owner-scoped fetch for the edit page. Without the `holder_id` filter
 * a holder could open another holder's published event URL and have the
 * edit form silently preload it (RLS still blocks saves, but the load
 * itself leaks edit affordances). Always use this for /seller/event/:id.
 */
export async function fetchMyEvent(id: string, holderId: string) {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('id', id)
    .eq('holder_id', holderId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as EventRow | null;
}

// `event_url` arrives before its column may exist (the
// `20260529000001_event_url.sql` migration is applied by hand in the
// Supabase SQL editor). Sending the field to a table without the column
// errors and would break ALL event creation/edits. So we strip it and
// retry once, mirroring the is_hidden pattern in fetchPublishedEvents.
//
// Two error shapes are possible depending on the path: raw Postgres
// returns `42703` (undefined_column), while PostgREST's schema cache
// returns `PGRST204` ("Could not find the 'event_url' column"). Tolerate
// both, scoped to event_url so we never mask an unrelated failure.
const isMissingEventUrl = (
  error: { code?: string; message?: string; details?: string } | null,
) => {
  if (!error) return false;
  const haystack = `${error.message ?? ''} ${error.details ?? ''}`;
  if (!/event_url/i.test(haystack)) return false;
  return error.code === '42703' || error.code === 'PGRST204';
};

export async function createEvent(holderId: string, input: EventUpsert) {
  if (assertClean(input.title, input.description).blocked) {
    throw new Error(GUIDELINE_MESSAGE);
  }
  const build = (withUrl: boolean) => {
    const payload: Record<string, unknown> = { ...input, holder_id: holderId };
    if (!withUrl) delete payload.event_url;
    return supabase.from('events').insert(payload).select('*').single();
  };
  let { data, error } = await build(true);
  if (isMissingEventUrl(error)) {
    console.warn('[CREATE_EVENT] event_url column missing — retrying without it. Apply migration 20260529000001_event_url.sql to enable event links.');
    ({ data, error } = await build(false));
  }
  if (error) throw new Error(error.message);
  return data as EventRow;
}

export async function updateEvent(id: string, patch: Partial<EventUpsert>) {
  // TEMP DIAGNOSTIC — remove after Event URL flow confirmed.
  console.log('[UPDATE_EVENT_DIAG] id + event_url in payload:', id, patch.event_url);
  const build = (withUrl: boolean) => {
    const payload: Record<string, unknown> = { ...patch };
    if (!withUrl) delete payload.event_url;
    return supabase.from('events').update(payload).eq('id', id).select('*').single();
  };
  let { data, error } = await build(true);
  if (isMissingEventUrl(error)) {
    console.warn('[UPDATE_EVENT] event_url column missing — retrying without it. Apply migration 20260529000001_event_url.sql to enable event links.');
    ({ data, error } = await build(false));
  }
  if (error) throw new Error(error.message);
  return data as EventRow;
}

export async function deleteEvent(id: string) {
  const { error } = await supabase.from('events').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

/* ---------------- Featured items ---------------- */

export async function fetchEventFeaturedItems(eventId: string) {
  const { data, error } = await supabase
    .from('event_featured_items')
    .select('*')
    .eq('event_id', eventId)
    .order('position', { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as EventFeaturedItem[];
}

export async function addEventFeaturedItem(
  eventId: string,
  item: { title: string; price?: number | null; image_url?: string | null; thumb_url?: string | null; position?: number },
) {
  const { data, error } = await supabase
    .from('event_featured_items')
    .insert({ event_id: eventId, ...item })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return data as EventFeaturedItem;
}

export async function deleteEventFeaturedItem(id: string) {
  const { error } = await supabase.from('event_featured_items').delete().eq('id', id);
  if (error) throw new Error(error.message);
}
