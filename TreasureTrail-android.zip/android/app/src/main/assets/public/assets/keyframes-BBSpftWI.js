var e=`__tt_ui_kf__`;function t(){if(typeof document>`u`||document.getElementById(e))return;let t=document.createElement(`style`);t.id=e,t.textContent=`
    @keyframes ttShimmer {
      0%   { background-position: -400px 0; }
      100% { background-position: 400px 0; }
    }
    @keyframes ttFadeIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    @media (prefers-reduced-motion: reduce) {
      .tt-shimmer, .tt-fade { animation: none !important; transition: none !important; }
    }
    /* Horizontal scroll rows (Discover): hide native scrollbars while
       keeping wheel / touch / drag scrolling enabled. */
    .tt-hscroll { scrollbar-width: none; -ms-overflow-style: none; }
    .tt-hscroll::-webkit-scrollbar { width: 0; height: 0; display: none; }
  `,document.head.appendChild(t)}export{t};